import AbstractView from "./AbstractView.js";

export default class extends AbstractView {
    constructor(params) {
        super(params);
        this.setTitle("Settings");
    }

    async getHtml() {
        return `
            <h1>Configurações</h1>
            <p>Gerencie sua privacidade e configuração.</p>
        `;
    }
}