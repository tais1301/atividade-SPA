import AbstractView from "./AbstractView.js";

export default class extends AbstractView {
    constructor(params) {
        super(params);
        this.setTitle("Dashboard");
    }

    async getHtml() {
        return `
            <h1>Bem-vindo a empresa TBC</h1>
            <p>
            Somos especialistas na implementação de soluções e tecnologias de alta qualidade, proporcionando aos nossos clientes uma vantagem competitiva de acordo com as suas necessidades.
            </p>
            <p>
                <a href="/posts" data-link>Veja as postagens recentes.</a>
            </p>
        `;
    }
}