import AbstractView from "./AbstractView.js";

export default class extends AbstractView {
    constructor(params) {
        super(params);
        this.setTitle("Posts");
    }

    async getHtml() {
        return `
            <h1>Postagens</h1>
            <iframe width="560" height="315" src="https://www.youtube.com/embed/Ev2-4HL8ftg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            <p>A FÁBRICA DA XIAOMI | DO INÍCIO AO EMBALAGEM FINAL</p><br><hr><br><br>

            <img src="https://www.oficinadanet.com.br/imagens/post/22924/330xNxxiaomi-12-pro-capa.jpg.pagespeed.ic.f49541a726.jpg">
            <p>O melhor telefone da Xiaomi: ótimas opções do básico ao auge em 2022</p>

        `;
    }
}